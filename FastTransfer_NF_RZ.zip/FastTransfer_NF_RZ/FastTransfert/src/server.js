require('dotenv').config();
const express = require('express');
const sequelize = require('./config'); 
const cors = require('cors'); 
const app = express();

app.use(cors());
app.use(express.json());


const User = require('./User'); 
const File = require('./File'); 


const userRoutes = require('./routes/userRoutes'); 
app.use('/users', userRoutes);


const fileRoutes = require('./routes/fileRoutes'); 
app.use('/files', fileRoutes);


(async () => {
  try {
    await sequelize.authenticate();
    console.log('Connexion à la base de données réussie.');

    
    await sequelize.sync();
    console.log('Base de données synchronisée.');

    const port = process.env.PORT || 3000;
    app.listen(port, () => console.log(`Serveur démarré sur le port ${port}`));
  } catch (error) {
    console.error('Erreur lors de la connexion à la base de données :', error);
  }
})();
