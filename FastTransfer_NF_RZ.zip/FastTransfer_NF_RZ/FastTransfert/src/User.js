
const { DataTypes } = require('sequelize');
const sequelize = require('./config'); 

const User = sequelize.define('User', {
  username: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
  quota: {
    type: DataTypes.INTEGER,
    defaultValue: 2048 
  },
  usedSpace: {
    type: DataTypes.INTEGER,
    defaultValue: 0 
  }
});

module.exports = User;

