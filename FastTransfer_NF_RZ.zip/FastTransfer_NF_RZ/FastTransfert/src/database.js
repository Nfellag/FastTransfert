const mysql = require('mysql2/promise');
const config = require('./config');

async function connect() {
  const connection = await mysql.createConnection(config.db);
  console.log('Connected to the database');
  return connection;
}

module.exports = { connect };
