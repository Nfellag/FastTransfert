const express = require('express');
const authenticateToken = require('../middleware/authenticateToken');
const { uploadFile, deleteFile, getFiles } = require('../controllers/fileController');
const router = express.Router();

router.post('/upload', authenticateToken, uploadFile);
router.delete('/:fileId', authenticateToken, deleteFile);
router.get('/', authenticateToken, getFiles);

module.exports = router;
