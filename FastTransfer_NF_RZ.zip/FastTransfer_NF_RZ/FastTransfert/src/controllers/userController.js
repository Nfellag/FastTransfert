const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { connect } = require('../database');
const config = require('../config');

async function registerUser(req, res) {
  
}

async function loginUser(req, res) {
  
}

module.exports = { registerUser, loginUser };
