const multer = require('multer');
const path = require('path');
const { connect } = require('../database');
const config = require('../config');

const storage = multer.diskStorage({
  destination: './uploads',
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

async function uploadFile(req, res) {
  
}

async function deleteFile(req, res) {
  
}

async function getFiles(req, res) {
  
}

module.exports = { uploadFile, deleteFile, getFiles };
