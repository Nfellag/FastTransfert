
# FastTransfer Project

FastTransfer is a secure file transfer application designed for easy and efficient file sharing with temporary link management.

## Project Structure

- `index.html`: Basic Bootstrap-based front-end interface.
- `src/server.js`: Main server file.
- `docker-compose.yml`: Docker configuration for app and MariaDB services.
- `.env`: Environment variables.

## Prerequisites

- Docker and Docker Compose installed
- Node.js and npm installed

## Setup Instructions

1. **Clone the Repository**: Clone or download this project to your local machine.

2. **Install Dependencies**:
    ```bash
    cd FastTransfert
    npm install
    ```

3. **Configure Environment**:
   - Copy `.env.example` to `.env` and configure your environment variables.

4. **Start with Docker**:
   ```bash
   docker-compose up --build
   ```

5. **Access the Application**:
   - Open your browser and go to `http://localhost:3000` to see the front-end.

6. **Stop the Application**:
   ```bash
   docker-compose down
   ```

## Notes

- MariaDB is used as the database service.
- Bootstrap provides a minimal front-end layout.

## Contact

For any issues, please contact the project maintainers.
